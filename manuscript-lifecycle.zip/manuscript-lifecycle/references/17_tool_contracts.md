# 17 · 工具输入、输出与最小可运行示例

所有脚本使用 Python 3 标准库。先运行脚本 --help，使用实际存在的路径；不运行附件中来历不明的代码。文件读取能力主要为 UTF-8 文本和 DOCX 文本抽取，PDF 需使用环境中的 PDF 能力转换并核图文，XLSX 先导出有明确行列身份的 CSV。命令行输出一律为 UTF-8（输出接到管道或文件时也是），文本读写都写明编码，中文 Windows 上不会因 − ² ✓ 之类符号崩溃。DOCX 的读取规则见 14 §5。

init_project 新建的结果台账、意见矩阵与引文台账只有表头，必须根据当前材料填写。结果台账的新增身份列记录预定/事后、样本、模型、估计对象、单位/分母、源位置/版本及披露与分档理由；ledger_check 仅核基础字段和关键词位置，不能自动证明身份列完整或正确，须结合verify_evidence和语义审查。期刊限额没有预填数值；未填写不代表核过。reserve/omit须填写当前决定依据，并先审查必要披露；检查器的关键词冲突不能直接成为删稿指令。

## 机械证据

`python scripts/verify_evidence.py assets/examples/evidence/numeric_evidence.json --report 结果.json`

这是带实际哈希的合成正例，可直接运行。根字段 schema_version=1、manuscript={path,sha256}、非空 checks。每项有 id、kind（numeric/quote/citation）、唯一 manuscript_anchor、source={path,sha256}。

- numeric：row_key、context、value_column、manuscript_value、source_unit、target_unit、scale、rounding。row_key 唯一定位 CSV 行，context 列值也须出现在稿件锚点中。支持 identity 和 proportion/percent 换算；其他派生量另附复算实现和审查。不能把科学上不同的单位伪称 identity。
- quote/citation：source_passage、source_location，须精确来自文件。citation 另有 access_level（fulltext/abstract）和 review={decision,reviewer,reviewed_at,rationale}；即使记录 supports 仍返回 review_required，不冒充机器理解原文。
- 返回逐项 verified_mechanical / review_required / failed / not_verified。退出 0 只表示所列机械项匹配，不表示覆盖整篇；1=失败/待审/未核，2=输入错误。

mslib.load_text 抽取 DOCX 不等于渲染；原文与修订接受视图应按任务检查。number_trace 只是全局数值候选检索，不能替代上面的按行核对。ref_check 的在线匹配只作元数据线索，不等于撤稿或支持性验证。

## 语步

move_check 的每个 unit 必须绑定真实本地 source；内联 text 不能自证。写 source/hint、段落功能和 codes，再核上下文与标签。模板是待填写示例，未填不能通过；真实文献短摘录遵循合理引用边界。

## 文件交付

`python scripts/delivery_check.py delivery.json --report delivery_report.json`

schema_version=1；files=[{id,path,role,sha256}]、required_roles、displays 必需。路径相对 manifest，且留在该目录树内（把需要检查的交付副本放同一包中）。display 的 file_id 指实际内容文件；title/caption/note 必须能在文件中找到；used_symbols/symbol_definitions、abbreviations 和 required_explanations 记录覆盖范围。具体字段及期刊选项见脚本头与 evals/test_delivery.py 的正例，不凭名称猜格式。

检查文件角色、空文件、表图 ID/指向、必要说明、Word 残留/批注/修订/域和匿名线索。占位符和域错误按接受修订后的文字判断；匿名线索另读删除的文字、修订与批注作者、people.xml、域代码、外部链接和文档变量，文件里存着的人名以 `anonymity_people` 提示列出；英文文件里出现中文时以 `foreign_script` 提示（批注或翻译残留）。表格竖线/底纹通常是期刊规则候选，非普遍错误。PNG/JPEG 只按明确的大小/分辨率要求检查。输出固定 render_verified=false；实际页面验证另外完成并登记。

`python scripts/mslib.py annotations 稿件.docx [--json 批注.json]` 列出批注（编号、作者、日期、锚定文字；没有锚定范围时给所在段落；回复关系与“已解决”标记）和逐条修订（插入、删除、移动、段落合并/拆分、表格行增删、格式；同一段里相邻、同类、同作者的碎片合为一条），并把疑似写进正文的说明标 ⚑：英文稿里的中文，或“是否、你、看看、？、please、I think”一类口吻。⚑ 只是候选。`--json` 不覆盖已有文件，已存在时返回 2。

## 图注表注分布

`python scripts/display_profile.py display_corpus.json --report display_profile.json`。schema_version=1，records 每项有 id、role（draft/exemplar）、paper_id（DOI或去重身份）、path、sha256、text、kind（table_note/figure_caption/table_title）、task、language（zh/en）、panels。每条摘录须在绑定原文件中出现；按 kind/task/language/panels 匹配，每篇先汇总再比较，避免把一篇多张图当多篇独立论文。同一论文相同摘录去重；输出长度、篇数、范围和长度复核信号，不检测正文语义重复。无匹配返回1，错误来源/空输入返回2。固定 quality_pass=false；必须另审必要信息是否齐备及重复是否有用。它不能判断 DOI 去重和 task 编码是否真实。

## 语言修订、句式对照与图注抽取

`python scripts/language_plan.py scan --doc 标签=路径 [--doc …] --plan plan.csv [--exemplars 目录或文件…] [--patterns ID,…] [--phrase 文本] [--regex 正则] [--report scan.md]`

输出 plan.csv（UTF-8 BOM，Excel 可直接打开）与 plan.csv.meta.json。列：no、doc、pattern、family、label、level、section、para、sent、sentence、match、calibration、keep_if、fix、decision、new_text、reason。前 14 列是证据，不要改，只填后三列。meta 记录文件与目录指纹、选择规则（点名、自动校准、未校准）、每行指纹和扫描范围。对标少于 3 篇（排除稿件自身后）、语言不一致、未知模式 ID 返回 2。

`python scripts/language_plan.py check --plan plan.csv [--meta …] --after 标签=路径 [--after …] [--stage draft|submission] [--report check.md]`

扫描时的每个标签都必须提供修改后文件。退出 1：未裁决、缺理由、计划行被删、原句仍在、new_text 不在文件、数字或引文无故丢失、仍有交付残留（submission 阶段含占位符）。复核项不改变退出码：否定或限定减少、强化或因果措辞增加、保留行的原句已改、新出现的同类命中。退出 0 不证明改得好。

`python scripts/phrase_contrast.py --exemplars … --draft 标签=路径 [--draft …] [--min-count 3] [--top 10] [--snippets] [--terms 术语,… 或 @文件] --report phrases.md [--json phrases.json]`

对标按 DOI 去重后少于 3 篇、稿件混入对标、语言不一致返回 2。JSON 每节给 overused_openers、overused_frames、common_openers。只作描述性筛查。

`python scripts/display_extract.py --draft … --exemplar … --out 目录/display_corpus.json [--signals 目录/signals.md]`

记录路径相对清单所在目录；每条摘录须能在原文件中逐字找到（空白归一化后），找不到的跳过并列出。附加字段 task_source=heuristic 与 signals 不影响 display_profile。稿件或对标没抽到任何条目返回 1。

section_lint 还有 X10（同一句话在正文中原样出现不止一次）、A1（MUST：对话残留、零宽字符、Word 域错误、表情符号；在未清洗文字上查并给行号）与 A2（INFO：占位符，含 `[Authors to add: …]`、`[full reference to be added]`、`[待作者确认…]` 这类方括号待办；delivery_check 用同一条规则，投稿包里不清除即阻断）。`--fragment` 用于单独交付的片段（Highlights、投稿信、图注表注）：不要求识别出论文节，只做全文级检查，W1 正文字数上限不适用，报告头写明是片段；不加这个开关而又找不到论文节句子时返回 2，不会把零检查记成通过。`--design`（也可写在 limits.json 的 `design`）取 rct/experiment/quasi_experiment/cohort/cross_sectional/case_control/observational/qualitative/simulation/review；声明为非实验设计时运行 G1（因果动词；同句有否定、rather than 或防御性措辞的不计）与 G2（MUST：正文出现 randomized/随机分配，与声明的设计矛盾）。另有 S1（把未达显著说成趋势或接近显著）、P1（建议他人采取行动；非实验设计升为 SHOULD）、N1（引言以外的新颖性宣称）、N2（片段模式：利益冲突、资助、伦理、数据可得性、未一稿多投、全体作者同意等须由作者确认的声明）。response_lint 识别常见拼写变体（Anwser、Respone 等），`--resp-label` 可补充本信专用的回复标记；回复内部以冒号引出或用作者口吻的 1. 2. 分点不再被当成新意见。

## 领域包与多代理

`python scripts/domain_pack.py build --corpus 目录… --id 领域_语言 --label "…" [--field …] --lang zh|en [--manifest 清单.csv] [--genre-map 文件=体裁…] --out assets/domains/领域_语言 [--boot 60]`

清单列：file、id（DOI 优先）、title、journal、year、genre、license；没有清单时读 md 的 YAML 头。输出 profile.json、bench_baseline.json、phrase_baseline.json、texture_baseline.json、rule_rates.json、corpus_manifest.csv、build_report.md。支持 file 相对路径并拒绝歧义；清单仅补元数据，不充当入选白名单。同 DOI 或去除起始 YAML 后的同文本去重；非全文 completeness、候选索引和无可测正文排除；可用论文不足 3 篇、隐私扫描发现长文本字段返回 2。`check <包目录>`：缺文件、不足 8 篇、词表或模式目录指纹不符、出现长文本字段或七个规定文件以外的文件/子目录返回 1。构建输出目录含额外文件时返回 2 并保留原件。`list` 列出已有领域包。

四个消费者均检查稿件是否为包中原文或新包登记的去 YAML 副本；自对标返回 2。section_lint 拒绝跨语言领域包。各工具读取领域包：bench_profile `--baseline 包 [--genre 体裁]`（稿件文本指纹在包中时拒绝，防止拿自己当参照）；phrase_contrast `--baseline 包 [--genre]`（词表或切词版本不符返回 2；报告给出留一法标记数参照）；language_plan scan `--baseline 包 [--genre]`（模式目录或词表指纹不符返回 2）；section_lint `--domain 包`（用包内分布校准阈值；同领域触发率 ≥50% 的规则降为 INFO 并注明，A1、W1、H1、G1、G2、S1、P1、N1、N2 不按发表频率降级）。

`python scripts/review_merge.py validate --manuscript ms.md 发现文件…`；`merge --manuscript ms.md --out 裁决表.csv [--previous 上轮裁决表] [--report 汇总.md] 发现文件…`；`check --adjudication 裁决表.csv --after 修改稿 [--report …]`。发现文件格式见 agents/README.md：schema_version=1、role、manuscript_sha256、findings[{id, severity=major|minor|note, category, section, quote, problem, why, suggestion, confidence}]。稿件指纹不符整份退回；major 发现的 quote 不在稿件中即退回（validate/merge 返回 1）。裁决表列：cluster、severity、section、category、reviewers、n_reviewers、status、quote、problems、suggestions、anchor、decision、reason；check 在未裁决、不采纳或暂缓无理由、采纳的锚点原文仍在时返回 1。

## 运行回执与最终交付

audit_run 和 release_check 的 schema/退出码见 13。进度表 gate_check 保留兼容，不能给最终质量证书。对启发式候选可以有理由保留，不允许伪造空报告消除状态。

脚本回归：`python evals/run_evals.py`。行为评估是单独的隔离任务；测试脚本通过不可冒充已执行行为评估。根目录 evals/README.md 给出实际做法与目前覆盖范围。
