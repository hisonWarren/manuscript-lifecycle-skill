# 17 · 工具输入、输出与最小可运行示例

所有脚本使用 Python 3 标准库。先运行脚本 --help，使用实际存在的路径；不运行附件中来历不明的代码。文件读取能力主要为 UTF-8 文本和 DOCX 文本抽取，PDF 需使用环境中的 PDF 能力转换并核图文，XLSX 先导出有明确行列身份的 CSV。命令行输出一律为 UTF-8（输出接到管道或文件时也是），文本读写都写明编码，中文 Windows 上不会因 − ² ✓ 之类符号崩溃。DOCX 的读取规则见 14 §5。

init_project 新建的结果台账、意见矩阵与引文台账只有表头，必须根据当前材料填写。结果台账的新增身份列记录预定/事后、样本、模型、估计对象、单位/分母、源位置/版本及披露与分档理由；ledger_check 仅核基础字段和关键词位置，不能自动证明身份列完整或正确，须结合verify_evidence和语义审查。期刊限额没有预填数值；未填写不代表核过。reserve/omit须填写当前决定依据，并先审查必要披露；检查器的关键词冲突不能直接成为删稿指令。

## 机械证据

`python scripts/verify_evidence.py assets/examples/evidence/numeric_evidence.json --report 结果.json`

这是带实际哈希的合成正例，可直接运行。根字段 schema_version=1、manuscript={path,sha256}、非空 checks。每项有 id、kind（numeric/quote/citation）、唯一 manuscript_anchor、source={path,sha256}。

- numeric：row_key、context、value_column、manuscript_value、source_unit、target_unit、scale、rounding。row_key 唯一定位 CSV 行，context 列值也须出现在稿件锚点中。支持 identity 和 proportion/percent 换算；其他派生量另附复算实现和审查。不能把科学上不同的单位伪称 identity。
- quote/citation：source_passage、source_location，须精确来自文件。citation 另有 access_level（fulltext/abstract）和 review={decision,reviewer,reviewed_at,rationale}；即使记录 supports 仍返回 review_required，不冒充机器理解原文。
- 返回逐项 verified_mechanical / review_required / failed / not_verified。退出 0 只表示所列机械项匹配，不表示覆盖整篇；1=失败/待审/未核，2=输入错误。

mslib.load_text 抽取 DOCX 不等于渲染；原文与修订接受视图应按任务检查。number_trace 只是全局数值候选检索，不能替代上面的按行核对。ref_check 的在线匹配只作元数据线索，不等于撤稿或支持性验证。

## 语步

move_check 的每个 unit 必须绑定真实本地 source；内联 text 不能自证。写 source/hint、段落功能和 codes，再核上下文与标签。模板是待填写示例，未填不能通过；真实文献短摘录遵循合理引用边界。

## 文件交付

`python scripts/delivery_check.py delivery.json --report delivery_report.json`

schema_version=1；files=[{id,path,role,sha256}]、required_roles、displays 必需。路径相对 manifest，且留在该目录树内（把需要检查的交付副本放同一包中）。display 的 file_id 指实际内容文件；title/caption/note 必须能在文件中找到；used_symbols/symbol_definitions、abbreviations 和 required_explanations 记录覆盖范围。具体字段及期刊选项见脚本头与 evals/test_delivery.py 的正例，不凭名称猜格式。

检查文件角色、空文件、表图 ID/指向、必要说明、Word 残留/批注/修订/域和匿名线索。占位符和域错误按接受修订后的文字判断；匿名线索另读删除的文字、修订与批注作者、people.xml、域代码、外部链接和文档变量，文件里存着的人名以 `anonymity_people` 提示列出；英文文件里出现中文时以 `foreign_script` 提示（批注或翻译残留）。表格竖线/底纹通常是期刊规则候选，非普遍错误。PNG/JPEG 只按明确的大小/分辨率要求检查。输出固定 render_verified=false；实际页面验证另外完成并登记。

`python scripts/mslib.py annotations 稿件.docx [--json 批注.json]` 列出批注（编号、作者、日期、锚定文字；没有锚定范围时给所在段落；回复关系与“已解决”标记）和逐条修订（插入、删除、移动、段落合并/拆分、表格行增删、格式；同一段里相邻、同类、同作者的碎片合为一条），并把疑似写进正文的说明标 ⚑：英文稿里的中文，或“是否、你、看看、？、please、I think”一类口吻。⚑ 只是候选。`--json` 不覆盖已有文件，已存在时返回 2。

## 图注表注分布

`python scripts/display_profile.py display_corpus.json --report display_profile.json`。schema_version=1，records 每项有 id、role（draft/exemplar）、paper_id（DOI或去重身份）、path、sha256、text、kind（table_note/figure_caption/table_title）、task、language（zh/en）、panels。每条摘录须在绑定原文件中出现；按 kind/task/language/panels 匹配，每篇先汇总再比较，避免把一篇多张图当多篇独立论文。同一论文相同摘录去重；输出长度、篇数、范围和长度复核信号，不检测正文语义重复。无匹配返回1，错误来源/空输入返回2。固定 quality_pass=false；必须另审必要信息是否齐备及重复是否有用。它不能判断 DOI 去重和 task 编码是否真实。

## 语言修订、句式对照与图注抽取

`python scripts/language_plan.py scan --doc 标签=路径 [--doc …] --plan plan.csv [--exemplars 目录或文件…] [--patterns ID,…] [--phrase 文本] [--regex 正则] [--report scan.md]`

输出 plan.csv（UTF-8 BOM，Excel 可直接打开）与 plan.csv.meta.json。列：no、doc、pattern、family、label、level、section、para、sent、sentence、match、calibration、keep_if、fix、decision、new_text、reason。前 14 列是证据，不要改，只填后三列。meta 记录文件与目录指纹、选择规则（点名、自动校准、未校准）、每行指纹和扫描范围。对标少于 3 篇（排除稿件自身后）、语言不一致、未知模式 ID 返回 2。

`python scripts/language_plan.py check --plan plan.csv [--meta …] --after 标签=路径 [--after …] [--stage draft|submission] [--report check.md]`

扫描时的每个标签都必须提供修改后文件。退出 1：未裁决、缺理由、计划行被删、原句仍在、new_text 不在文件、数字或引文无故丢失、仍有交付残留（submission 阶段含占位符）。复核项不改变退出码：否定或限定减少、强化或因果措辞增加、保留行的原句已改、新出现的同类命中。退出 0 不证明改得好。

`python scripts/phrase_contrast.py --exemplars … --draft 标签=路径 [--draft …] [--min-count 3] [--top 10] [--snippets] [--terms 术语,… 或 @文件] --report phrases.md [--json phrases.json]`

对标按 DOI 去重后少于 3 篇、稿件混入对标、语言不一致返回 2。JSON 每节给 overused_openers、overused_frames、common_openers。只作描述性筛查。

`python scripts/display_extract.py --draft … --exemplar … --out 目录/display_corpus.json [--signals 目录/signals.md]`

记录路径相对清单所在目录；每条摘录须能在原文件中逐字找到（空白归一化后），找不到的跳过并列出。附加字段 task_source=heuristic 与 signals 不影响 display_profile。稿件或对标没抽到任何条目返回 1。

section_lint 还有 X10（同一句话在正文中原样出现不止一次）、A1（MUST：对话残留、零宽字符、Word 域错误、表情符号；在未清洗文字上查并给行号）与 A2（INFO：占位符，含 `[Authors to add: …]`、`[full reference to be added]`、`[待作者确认…]` 这类方括号待办；delivery_check 用同一条规则，投稿包里不清除即阻断）。`--fragment` 用于单独交付的片段（Highlights、投稿信、图注表注）：不要求识别出论文节，只做全文级检查，W1 正文字数上限不适用，报告头写明是片段；不加这个开关而又找不到论文节句子时返回 2，不会把零检查记成通过。`--design`（也可写在 limits.json 的 `design`）取 rct/experiment/quasi_experiment/cohort/cross_sectional/case_control/observational/qualitative/simulation/review；声明为非实验设计时运行 G1（因果动词；同句有否定、rather than 或防御性措辞的不计）与 G2（MUST：正文出现 randomized/随机分配，与声明的设计矛盾）。另有 S1（把未达显著说成趋势或接近显著）、P1（建议他人采取行动；非实验设计升为 SHOULD）、N1（引言以外的新颖性宣称）、N2（片段模式：利益冲突、资助、伦理、数据可得性、未一稿多投、全体作者同意等须由作者确认的声明）。response_lint 识别常见拼写变体（Anwser、Respone 等），`--resp-label` 可补充本信专用的回复标记；回复内部以冒号引出或用作者口吻的 1. 2. 分点不再被当成新意见。

## 领域包与多代理

`python scripts/domain_pack.py build --corpus 目录… --id 领域_语言 --label "…" [--field …] --lang zh|en [--manifest 清单.csv] [--genre-map 文件=体裁…] --out assets/domains/领域_语言 [--boot 60]`

清单列：file、id（DOI 优先）、title、journal、year、genre、license；没有清单时读 md 的 YAML 头。输出 profile.json、bench_baseline.json、phrase_baseline.json、texture_baseline.json、rule_rates.json、corpus_manifest.csv、build_report.md。支持 file 相对路径并拒绝歧义；清单仅补元数据，不充当入选白名单。同 DOI 或去除起始 YAML 后的同文本去重；非全文 completeness、候选索引和无可测正文排除；可用论文不足 3 篇、隐私扫描发现长文本字段返回 2。`check <包目录>`：缺文件、不足 8 篇、词表或模式目录指纹不符、出现长文本字段或七个规定文件以外的文件/子目录返回 1。构建输出目录含额外文件时返回 2 并保留原件。`list` 列出已有领域包。

四个消费者均检查稿件是否为包中原文或新包登记的去 YAML 副本；自对标返回 2。section_lint 拒绝跨语言领域包。各工具读取领域包：bench_profile `--baseline 包 [--genre 体裁]`（稿件文本指纹在包中时拒绝，防止拿自己当参照）；phrase_contrast `--baseline 包 [--genre]`（词表或切词版本不符返回 2；报告给出留一法标记数参照）；language_plan scan `--baseline 包 [--genre]`（模式目录或词表指纹不符返回 2）；section_lint `--domain 包`（用包内分布校准阈值；同领域触发率 ≥50% 的规则降为 INFO 并注明，A1、W1、H1、G1、G2、S1、P1、N1、N2 不按发表频率降级）。

`python scripts/review_merge.py validate --manuscript ms.md 发现文件…`；`merge --manuscript ms.md --out 裁决表.csv [--previous 上轮裁决表] [--report 汇总.md] 发现文件…`；`check --adjudication 裁决表.csv --after 修改稿 [--report …]`。发现文件格式见 agents/README.md：schema_version=1、role、manuscript_sha256、findings[{id, severity=major|minor|note, category, section, quote, problem, why, suggestion, confidence}]。稿件指纹不符整份退回；major 发现的 quote 不在稿件中即退回（validate/merge 返回 1）。裁决表列：cluster、severity、section、category、reviewers、n_reviewers、status、quote、problems、suggestions、anchor、decision、reason；check 在未裁决、不采纳或暂缓无理由、采纳的锚点原文仍在时返回 1。

## 运行回执与最终交付

audit_run 和 release_check 的 schema/退出码见 13。进度表 gate_check 保留兼容，不能给最终质量证书。对启发式候选可以有理由保留，不允许伪造空报告消除状态。

脚本回归：`python evals/run_evals.py`。行为评估是单独的隔离任务；测试脚本通过不可冒充已执行行为评估。根目录 evals/README.md 给出实际做法与目前覆盖范围。

## journal_check.py · 期刊规则档案

档案在 `assets/journal_profiles/`，`schema_version=1`，必须有 `id`、`journal`、`sources`、`rules`。每条 `sources` 写 `id`、`url`、`access`（访问到的是什么：官方网页正文、存档副本、二手来源或未访问）和 `accessed`（日期）。每条 `rules` 写 `id`、`check`、`level`、`status`（verified 或 unverified）、`source`（指向 sources 的 id）和 `note`。缺任何一项，脚本退出 2。

`status=unverified` 的规则，即使写了 `level: FAIL` 也只报 CAND，并注明“来源未核实”。期刊规则会改版，凭记忆或第三方转述写死数字，比不检查更糟。

已实现的 `check`：`title_chars`、`abstract_words`、`abstract_numbers`、`abstract_citations`、`main_words`、`heading_chars`、`legend_words`、`note_words`、`legend_no_methods`、`legend_defines_stats`、`legend_conclusion`、`highlights`（`max_n`、`max_chars`）、`one_sentence_summary`、`in_brief_words`、`results_display_led`。未实现的 check 报 INFO 并跳过，不静默忽略。描述读图编码的句子（thicker lines indicate…、粗体表示…）不算下结论。

`--baseline` 读 `assets/benchmarks/display_baseline.json`，按档案的 `display_family` 给出本条说明在实测分布中的位置。`--fragment` 用于单独交付的 Highlights、投稿信、图注表注，跳过整稿项目。`--list` 列出档案，`--show` 打印某个档案的全部规则与来源。

目标刊不在档案里时，按当期作者须知新建一份，写明 URL 与访问日。**档案里没有的项目不检查，也不虚构“期刊要求”**；脚本通过不代表全部符合期刊要求。

## table_style.py · 三线表生成与版式检查

`build` 从 CSV 生成 docx：三线表边框、表头跨页重复、数据行不跨页、数值列右对齐并统一小数位、表题在上、表注在下。CSV 行列数不一致时退出 2，并提示给含逗号的字段加引号。输出文件已存在时拒绝覆盖。

`check` 读 docx 或 md：竖线与内部横线、表头下横线缺失、表头重复与行跨页、同列小数位不一致、`p = 0.000`、区间写法混用、表注顺序、超长注释。只有表注、没有表格的片段也能检查；既无表格也无表注时退出 2，不把零检查当通过。

它检查结构，**不是版式验收**。列宽、断词、跨页表头、上下标、负号仍须渲染后逐页看，报告里固定写明这一点。

## section_lint.py 的 S2 · 把比较写成“相同”

同句出现 identical、equivalent、the same、完全一致、毫无差异等措辞，且有统计量或组间比较的字样时列出。同句报告了不显著的检验（p ≥ .05、did not differ、不显著）为 SHOULD，否则为 INFO。等效性检验、贝叶斯因子、描述材料与程序的句子（materials were identical to Experiment 1）以及紧挨着的否定（not identical）不算。S2 不按领域发表频率降级。

## check_all.py · 一条命令的检查与状态页

`python scripts/check_all.py 稿件 [--out 目录] [--results 结果文件…] [--allow allow.txt] [--design 设计] [--domain 领域包] [--profile 期刊档案] [--ledger 台账] [--supplement 补充] [--simulation]`

依次运行 section_lint、density_check、ref_check；给了 `--results` 运行 number_trace（只查摘要、结果、讨论、局限、结论与表图题注），给了 `--ledger` 运行 ledger_check，给了 `--profile` 运行 journal_check；`--simulation` 检查开头的模拟标识，以及模拟稿里不该出现的伦理批准与知情同意。

输出目录默认在稿件旁新建“检查_时间”，已有文件的目录拒绝复用（退出 2）。STATUS.md 分四块：必须先处理、没能运行（不算通过）、需要看一眼、机器查不了需要人看的。台账列名与模板不同时只报一次“没能运行”，不逐行刷屏。

`--allow` 文件每行“数字 # 理由”，登记不来自结果文件的数字（任务参数、种子、版本号）。登记过的数字不阻断，但会连同理由列进 STATUS.md 请作者复核；没写理由的行不生效。number_trace 本身不接受全局豁免，这一层登记只在 check_all 里做，且留下记录。

退出码：0 没有必须处理的问题且请求的检查都跑了；1 有必须处理的问题或有检查没能运行；2 输入错误。

## section_lint 的 X11、X12 · 写作过程进了稿件

X11（MUST）：稿件任何位置出现工具名、对标或门控说明、“作者待办”、审计列表等写作过程的痕迹，例如把“句式分布对标未完成”写进局限，或把作者待办接在参考文献后面。文件头的 YAML 元数据与代码块不查。X11 不按领域发表频率降级。

X12（SHOULD）：摘要、结果、讨论、局限或结论里出现本地文件路径或脚本名。数据与代码的位置写进可得性声明，用公开仓库地址或 DOI。

## number_trace 的阈值写法

`p < .001`、`P ≤ 0.01` 这类写法，只要结果文件里有一个更小的非负值就算匹配。它不核对是哪一个 p，承重的 p 值仍要按行核对。

## init_project 只建本模式用得到的模板

D：盘点、来源覆盖、类型、故事卡、结果台账、大纲、决策登记、引文台账；R：盘点、故事卡、台账、决策登记、主张登记、引文台账；S：投稿清单、投稿信、限额、引文台账、决策登记；V：盘点、意见矩阵、回复信、主张登记、决策登记；A：盘点、问题登记、评分量表、引文台账。作者说明在项目根目录“作者说明.md”。`--full` 拷入全部模板。

## lit_evidence.py · 文献证据阶梯

`resolve --ledger 台账 --out 新台账 [--online] [--sources crossref,openalex] [--fixtures 目录] [--save-raw 目录] [--mailto 邮箱]`：逐个 DOI 查 Crossref（`/works/{doi}`）与 OpenAlex（`/works/doi:{doi}`，环境变量 OPENALEX_API_KEY 可选）。填 doi_status、identity（ref_title、ref_first_author、ref_year 与注册库比对；年份差 1 年以内视为一致）、version_status 与 version_source（Crossref `updated-by` 的 correction、erratum、retraction、withdrawal、expression of concern；OpenAlex `is_retracted`）、tool、checked_on。请求了核对却失败记 not_verified；所查注册库都返回 404 记 not_in_index；只有 OpenAlex 的 is_retracted=false 时 version_status 记 inconclusive。`--fixtures` 读以前保存的注册库记录（文件名 `crossref_<DOI>.json`，“/”换成“_”），用于无网复查与测试；`--save-raw` 保存本次取到的原始记录。输出文件已存在时拒绝写入。

`check [--ledger 台账] [--text 文件…] [--execution …] [--benchmark-mode …] [--benchmark-report 报告] [--benchmark-corpus 目录或清单] [--min-distribution 8]`：核对台账枚举、主张类型与访问程度（数字、方法、机制、比较、发现要 fulltext；存在性与背景至少 abstract）、resolved 是否写了工具与日期、REASONING-ONLY 下的 resolved 记录（沿用旧记录须在 tool 写“沿用”或来自 `--fixtures`）、更正与撤稿是否写了影响；扫描文本里的 F01–F16 说法，否定句不计。退出码 0 无 FAIL；1 有 FAIL 或字段错误；2 输入错误。

它只核对说法与记录是否对得上：DOI 能解析不等于支持本句；未见撤稿不等于可靠；relation 与 citation_access 要读过原文的人来填。

## metric_audit.py · 指标复算

`--csv 行级数据 --spec 口径.json --out 结果.json`。口径文件 schema_version=1，`group_by` 指定分组列；`metrics` 每项 kind 为 rate（numerator、denominator、aggregation=pooled 或 mean_row_ratios）、event_fraction（column、positive_values）、capped_mean（column、event_column、event_values、cap）或 mean。`reported_by_group` 可选，给出稿件报告的值；默认容差是报告值末位小数的半个单位（0.070 → 0.005），`tolerance` 可显式指定。退出 1 = 报告值与复算不符；2 = 输入或口径错误；输出文件已存在时拒绝写入。列选对不等于科学定义正确。

## reference_identity.py · 单条 DOI 的书目比对

`DOI --title 题名 --author 第一作者姓 --year 年份 [--report 报告]`：向 Crossref 取记录，比对题名、第一作者与年份。退出 0 一致；1 不一致或无法核实；2 输入错误。不核主张支持。批量核对用 lit_evidence resolve。

## check_all.py 的其他选项

`--design` 认常见写法（cluster-rct、randomised、longitudinal、survey、横断面等），认不出就退出 2 并列出可用名称。`--allow` 里的 95 与 95%、1,240 与 1240 视为同一登记。`--qualifiers`（values、requires 两列）：提到这些数字的句子，本句或上一句没有限定词就列为必须处理。给了 `--results` 时，稿件里的伦理批准号与注册号（NCT、ISRCTN、ChiCTR、ACTRN、DRKS、CRD、osf.io）要能在结果与材料文件里找到；说已注册却没有注册号，材料写明未注册时列为必须处理，否则列为看一眼。正文有作者–年份或编号引文却没有参考文献表时列为必须处理。`--citations`、`--note`、`--execution`、`--benchmark-mode`、`--benchmark-report`、`--benchmark-corpus` 交给 lit_evidence check。`--simulation` 只核对题目下那一句标识；稿件里的伦理与同意说法列为看一眼（只保留材料写明的）。

## number_trace.py 的变化

来源里原样出现的百分数（62.0%、9.8%）算有出处；“95% CI”里的 95% 是区间水平，不计入核对；派生或换算出来的百分数仍要登记理由。`--json` 另存未匹配清单。

## section_lint.py 的变化

X13（MUST）：摘要或结论里的待办清单或稿件状态话（伦理、资助、文献待补；“本稿未提供”“待作者核实”“写作流程测试”）。X14（SHOULD）：摘要或结论里的行内待核事实占位（如 [VERIFY: city]）。X11 增加稿件状态话的写法；题目下一句纯粹的合成数据标识不计。I1 认“The primary question … was whether”“we asked whether”等目的句；S1 认“showed a trend towards improvement”。紧跟表或题注的“注 / Note.”按表注处理，不计入所在节的正文。

X15（SHOULD）：方法、结果、讨论、局限里的内部处理过程（重跑、合并出错、Excel 清洗）。P2（SHOULD）：用因果动词描述使用量或剂量梯度（组内按使用量分组的比较是观察性的，随机试验也一样）。S2 的程序句豁免不适用于带置信区间或 p 值的句子（“多重插补证实两组等同（1.5，95% CI …）”会被报出）。

check_all 的输出目录：`--out` 指向的目录已有报告时，写到 `目录_2`、`目录_3`……，并在 STATUS.md 写明上一轮报告的位置；旧报告不覆盖。STATUS.md 每条末尾的括号写明工具与规则代码（如 `section_lint R1`、`number_trace NT1`、`check_all SIM3`、`qualifiers Q1`），同目录的 `summary.json` 列出同样的条目（tool、code、text）、退出码与所用选项。check_all 自己的代码：NT0 没给结果文件，NT1 数字找不到出处，NT2 已登记理由的数字；RC1 正文有引文却没有参考文献表，RC2 还没有参考文献表，RC3 引文与文献表对不上；SIM1 缺模拟标识，SIM2 伦理说法待核对，SIM3 伦理说法在给出的材料里找不到；ID1 编号在材料里找不到，ID2 编号无从核对；REG1 说已注册却没有注册号；Q1 缺口径限定；EX1 没写执行条件；LC1 结果台账错误。口径限定的匹配跳过版本号与软件包名里的数字（R 4.4.1、lme4 1.1-35），− 与 - 视为相同。

`check_stats.py 目录… [--notes 作者说明…] [--report 汇总.md] [--json 汇总.json]`：递归读取 summary.json，汇总运行次数、可交次数、没能运行的检查，以及每条规则的命中次数、出现在几次运行里、被作者说明列为误报的次数（读写有“误报”的行与小节里的规则代码）。用于监控，不判断规则对错。退出 2：没找到 summary.json。

section_lint：R1 在解释句比例超过阈值且不少于 3 句时才是 MUST；中文“提示”只在作动词时（“结果提示”“这提示”）计入。P2 跳过明确否认因果的句子（“不能推出”“cannot be interpreted as”）。V1（SHOULD）：图注写了线型、颜色或标记，提醒核对实际的图。V2（SHOULD）：表注或图注下了结论（demonstrate、表明、优于），或写了软件与估计细节（REML、lme4、R 4.4.1）。X11 也包括“材料里没有记录”这类材料缺口的说法。

response_lint 的 `--comments` 可以给条数，也可以给审稿意见文件，按行首编号（E1、R1.1）计数。
