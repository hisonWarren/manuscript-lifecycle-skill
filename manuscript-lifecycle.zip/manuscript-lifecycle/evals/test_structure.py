import ast
import re
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]

class PackageStructure(unittest.TestCase):
    def test_scripts_parse(self):
        for p in (ROOT/'scripts').glob('*.py'):
            with self.subTest(path=p.name): ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
    def test_local_markdown_links_resolve(self):
        for p in [ROOT/'SKILL.md',*(ROOT/'references').glob('*.md')]:
            for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8-sig')):
                if re.match(r'https?://|#',target): continue
                target=target.split('#')[0]
                with self.subTest(source=p.name,target=target): self.assertTrue((p.parent/target).exists())
    def test_entrypoint_frontmatter(self):
        text=(ROOT/'SKILL.md').read_text(encoding='utf-8-sig')
        self.assertTrue(text.startswith('---\n'))
        header=text.split('---',2)[1]
        self.assertRegex(header,r'(?m)^name: manuscript-lifecycle$')
        self.assertRegex(header,r'(?m)^description:')

if __name__=='__main__':unittest.main()
