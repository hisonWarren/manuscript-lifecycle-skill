#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
init_project.py — 建项目工作区：目录、模板、按模式预填的门控表。已存在的文件不覆盖。

  python init_project.py --dir 项目目录 --mode D|R|S|V|A [--title 短题] [--full]

只建本模式用得到的模板；作者先看的说明在项目根目录“作者说明.md”，其余是工作区。

模式：D 从数据写初稿；R 修改已有稿件；S 准备投稿；V 返修与回复审稿人；A 投稿前自审。
"""
import argparse, os, shutil, sys

# Windows 中文系统把输出接到管道时默认按 GBK 编码，统计里常见的 − ² ✓ 会让脚本在打印时崩溃；统一按 UTF-8 输出。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(os.path.dirname(HERE), "assets", "templates")
GATES = [("G0", "材料盘点与阶段判断", "00_inputs/inventory.md"), ("G1", "论文类型与评价对象", "01_frame/paper_type.md"),
         ("G2", "故事卡", "01_frame/story_card.md"), ("G3", "结果台账与报告分档", "01_frame/results_ledger.csv; 04_audit/ledger_check.md"),
         ("G4", "对标语料与画像", "02_bench/corpus.md; 02_bench/bench_report.md"), ("G5", "大纲与各节契约", "03_draft/outline.md"),
         ("G6", "逐节初稿", "03_draft/manuscript.md"),
         ("G7", "审计", "04_audit/section_lint.md; 04_audit/density.md; 04_audit/number_trace.md; 04_audit/ref_check.md; 04_audit/claims_guard.md; 04_audit/review_findings.md"),
         ("G8", "分层修订", "05_revision/decision_log.md; 05_revision/changes.md"), ("G9", "投稿材料", "06_submission/submission_checklist.md"),
         ("G10", "返修与回复信", "07_response/comments_matrix.csv; 07_response/response_lint.md"), ("G11", "投稿前自审", "04_audit/self_review.md"),
         ("H1", "人工确认：类型、故事卡、台账", ""), ("H2", "人工通读：首个完整稿", ""), ("H3", "人工通读：投稿或返修前", "")]
REQ = {"D": "G0 G1 G2 G3 G4 G5 G6 G7 G8", "R": "G0 G2 G3 G7 G8", "S": "G7 G9", "V": "G0 G10 G7", "A": "G0 G11"}
COPY = {"inventory.md": "00_inputs", "paper_type.md": "01_frame", "story_card.md": "01_frame", "results_ledger.csv": "01_frame",
        "outline.md": "03_draft", "claims_register.json": "05_revision", "decision_log.md": "05_revision", "limits_example.json": "00_inputs",
        "submission_checklist.md": "06_submission", "cover_letter.md": "06_submission", "comments_matrix.csv": "07_response",
        "response_letter.md": "07_response", "moves_coding_example.json": "02_bench", "draft_rubric.md": "04_audit",
        "citation_ledger.csv": "04_audit", "task_brief.md": "00_inputs", "qualifiers.csv": "01_frame", "issue_log.csv": "04_audit", "author_delivery.md": "06_submission", "source_coverage.csv": "00_inputs"}


# 只建这一模式用得到的文件：实地试写中，初稿项目里有 9 个模板从建好到交付一字未动，作者打开先看到一堆空壳。
# 其余模板在 assets/templates/，用到时再拷；--full 恢复旧行为（全部拷入）。
BY_MODE = {
    "D": ["task_brief.md", "inventory.md", "source_coverage.csv", "paper_type.md", "story_card.md", "results_ledger.csv", "qualifiers.csv",
          "outline.md", "decision_log.md", "citation_ledger.csv"],
    "R": ["task_brief.md", "inventory.md", "story_card.md", "results_ledger.csv", "qualifiers.csv", "decision_log.md", "claims_register.json", "citation_ledger.csv"],
    "S": ["submission_checklist.md", "cover_letter.md", "limits_example.json", "citation_ledger.csv", "decision_log.md"],
    "V": ["task_brief.md", "inventory.md", "comments_matrix.csv", "response_letter.md", "claims_register.json", "qualifiers.csv", "decision_log.md"],
    "A": ["inventory.md", "issue_log.csv", "draft_rubric.md", "citation_ledger.csv"],
}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir", required=True); ap.add_argument("--mode", required=True, choices=list(REQ)); ap.add_argument("--title", default="")
    ap.add_argument("--full", action="store_true", help="拷入全部模板（旧行为）")
    a = ap.parse_args()
    want = set(COPY) if a.full else set(BY_MODE[a.mode])
    for d in sorted({"03_draft", "04_audit"} | {COPY[f] for f in want}):
        os.makedirs(os.path.join(a.dir, d), exist_ok=True)
    made = []
    note = os.path.join(a.dir, "作者说明.md")
    if not os.path.exists(note) and os.path.exists(os.path.join(TPL, "author_delivery.md")):
        shutil.copy(os.path.join(TPL, "author_delivery.md"), note); made.append("作者说明.md")
    for f, d in COPY.items():
        if f not in want or f == "author_delivery.md":
            continue
        src, dst = os.path.join(TPL, f), os.path.join(a.dir, d, f)
        if os.path.exists(src) and not os.path.exists(dst):
            shutil.copy(src, dst); made.append(os.path.join(d, f))
    gl = os.path.join(a.dir, "gate_log.md")
    if not os.path.exists(gl):
        req = REQ[a.mode].split()
        L = ["# 门控记录%s" % ((" · " + a.title) if a.title else ""), "", "MODE: %s" % a.mode,
             "本模式进度项：%s。gate_check 仅检查日志一致性，不是交付证书；最终证据契约见 release_check。H 行为作者决策提醒，不代签、不阻断已授权的可逆写作。" % " ".join(req), "",
             "| 门控 | 状态 | 证据 | 备注 |", "|---|---|---|---|"]
        L += ["| %s %s%s | todo | %s |  |" % (c, n, "（必需）" if c in req else "", e) for c, n, e in GATES]
        L += ["", "DONE: no", ""]
        open(gl, "w", encoding="utf-8").write("\n".join(L)); made.append("gate_log.md")
    print("工作区：%s；新建 %d 个文件：%s" % (a.dir, len(made), "、".join(made)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
