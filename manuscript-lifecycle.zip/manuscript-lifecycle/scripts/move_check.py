#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
move_check.py — 语步（rhetorical move）对照：先核实编码有原文依据，再比较稿件与同类文献的段落功能结构。

  python move_check.py 编码.json [--report out.md] [--min-common 0.6] [--max-rare 0.2]

编码文件格式见 assets/templates/moves_coding_example.json。每个单元是一篇文献（或稿件）的一个目标段落，
例如 intro_last 引言末段、disc_first 讨论首段、conclusion 结论。逐句给出 [语步代码, 该句中逐字出现的线索短语]。
为什么要线索短语：模型给范文"编码"时最容易凭印象编。线索短语必须逐字（忽略大小写与标点）出现在该段，且按句序排列；
脚本只核对线索是否存在及顺序，不能验证语义标签。必须提供单独的 source 文件；内嵌 text 也须能在该源中找到。
编码条数与该段句数相差应 ≤1，否则提示漏编、合并编码或断句失败。
比较内容：各语步在对标文献中的出现比例，首句与末句的语步分布；稿件缺少的常见语步（≥min-common），稿件有而对标少见的语步（≤max-rare）。
退出码：0 文本线索核对完成（语义未验证）；1 有找不到的线索、非法代码或覆盖问题；2 输入错误或零覆盖。
"""
import argparse, collections, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mslib as M

MOVES = {
    "CTX": "背景/重要性/公认看法", "LIT": "既往研究", "DEF": "概念/定义", "GAP": "空白/未知", "TEN": "张力/相反证据",
    "STK": "后果/为何重要", "AIM": "目的/问题", "HYP": "假设/预期", "DES": "设计/数据（引言预告或讨论重述）",
    "SCO": "范围/探索性说明", "VAL": "价值/新颖性", "FND": "主要发现", "INT": "解释/含义收束", "CMP": "与既往研究比较",
    "MEC": "可能机制", "IMP": "临床/实践含义", "QUA": "限定/局限", "FUT": "未来研究（具体）", "GEN": "一般性结论",
    "MTH": "方法学解释", "MDS": "研究设计", "MSRC": "数据来源/场所", "MREC": "招募", "MELG": "纳入排除",
    "MNUM": "人数/流程/人口学", "METH": "伦理/知情同意", "MTIME": "时间/日程", "MINS": "测量工具", "MANA": "分析步骤",
    "MRAT": "分析理由/目的", "MFIT": "拟合/显著性标准", "MMIS": "缺失数据", "MSW": "软件", "MSEN": "敏感性分析",
    "MTRN": "透明度/预注册声明", "MREF": "引用他处细节", "MORD": "结果呈现顺序", "RSUM": "结果：发现陈述",
    "RNUM": "结果：数字与区间", "RPTR": "结果：指向表图", "RCMP": "结果：组间/模型比较",
}


def locate(unit, base):
    src = unit.get("source", "")
    path = src if os.path.isabs(src) else os.path.join(base, src)
    if not src or not os.path.isfile(path):
        return None
    source_text = M.load_text(path)
    if unit.get("text"):
        # The supplied excerpt is evidence only when located in a separate source.
        return unit["text"] if M.norm_for_match(unit["text"]) in M.norm_for_match(source_text) else None
    hint = M.norm_for_match(unit.get("hint", ""))
    for b in M.parse(source_text):
        if b["kind"] in ("para", "caption") and hint and hint in M.norm_for_match(b["text"]):
            return b["text"]
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("coding"); ap.add_argument("--report", default="")
    ap.add_argument("--min-common", type=float, default=0.6); ap.add_argument("--max-rare", type=float, default=0.2)
    a = ap.parse_args()
    try:
        data = json.load(open(a.coding, encoding="utf-8-sig"))
    except Exception as e:
        print("编码文件读取失败：%s" % e, file=sys.stderr); return 2
    if not isinstance(data, dict) or not isinstance(data.get("units"), list) or not data["units"]:
        print("not_verified：units 必须是非空列表", file=sys.stderr); return 2
    if not isinstance(data.get("moves", {}), dict):
        print("moves 必须是对象", file=sys.stderr); return 2
    moves = dict(MOVES); moves.update(data.get("moves", {}))
    base = os.path.dirname(os.path.abspath(a.coding))
    errors, warns, ok_units = [], [], []
    for u in data.get("units", []):
        if not isinstance(u, dict) or u.get("role") not in ("draft", "exemplar", "ex") or not isinstance(u.get("codes"), list) or not u["codes"]:
            errors.append("单元缺少有效 role 或非空 codes"); continue
        tag = "%s·%s" % (u.get("paper", "?"), u.get("section", "?"))
        if any(not isinstance(c, list) or len(c) != 2 or not all(isinstance(x, str) and x.strip() for x in c) for c in u["codes"]):
            errors.append("%s：每条编码须为非空的 [代码, 原文线索]" % tag); continue
        para = locate(u, base)
        if para is None:
            errors.append("%s：找不到段落（检查 source 与 hint）" % tag); continue
        np_ = M.norm_for_match(para); pos = -1; uerr = False
        for code, cue in u.get("codes", []):
            if code not in moves:
                errors.append("%s：未定义的语步代码 %s" % (tag, code)); uerr = True; continue
            nc = M.norm_for_match(cue)
            nw = len(nc.split()) if not M.CJK.search(cue) else len(M.CJK.findall(cue)) / 2
            if nw < 2 or nw > 20:
                warns.append("%s：线索「%s」长度不合适（2–20 词）" % (tag, cue[:40]))
            i = np_.find(nc)
            if i < 0:
                errors.append("%s：线索「%s」不在原文中" % (tag, cue[:60])); uerr = True; continue
            if i < pos:
                errors.append("%s：线索「%s」与句序不符" % (tag, cue[:40])); uerr = True
            pos = max(pos, i)
        ns = len(M.sentences(para))
        if abs(ns - len(u.get("codes", []))) > 1:
            errors.append("%s：编码 %d 条，该段 %d 句（应逐句编码；断句异常须先修复）" % (tag, len(u.get("codes", [])), ns)); uerr = True
        if not uerr:
            ok_units.append(u)
    by = collections.defaultdict(lambda: {"ex": [], "draft": []})
    for u in ok_units:
        by[u.get("section", "?")]["draft" if u.get("role") == "draft" else "ex"].append(u)
    L = ["# 语步对照报告\n", "单元 %d 个，文本线索匹配 %d 个；错误 %d、提示 %d。\n" % (len(data.get("units", [])), len(ok_units), len(errors), len(warns))]
    if errors:
        L.append("## 编码错误（必须修正：线索必须逐字来自原文）\n"); L += ["- " + e for e in errors]
    if warns:
        L.append("\n## 提示\n"); L += ["- " + w for w in warns]
    for sec, g in by.items():
        ex = g["ex"]
        if not ex:
            continue
        n = len(ex)
        pres = collections.Counter(m for u in ex for m in {c for c, _ in u["codes"]})
        first = collections.Counter(u["codes"][0][0] for u in ex if u["codes"])
        last = collections.Counter(u["codes"][-1][0] for u in ex if u["codes"])
        L.append("\n## %s（对标 %d 篇）\n" % (sec, n))
        L.append("| 语步 | 含义 | 出现篇数 | 比例 | 作首句 | 作末句 |\n|---|---|---|---|---|---|")
        for m, c in pres.most_common():
            L.append("| %s | %s | %d | %.0f%% | %d | %d |" % (m, moves.get(m, ""), c, 100 * c / n, first.get(m, 0), last.get(m, 0)))
        for d in g["draft"]:
            dm = [c for c, _ in d["codes"]]
            common = [m for m, c in pres.items() if c / n >= a.min_common and m not in dm]
            rare = sorted({m for m in dm if pres.get(m, 0) / n <= a.max_rare})
            L.append("\n**%s**：语步序列 %s" % (d.get("paper", "稿件"), " → ".join(dm)))
            L.append("- 对标中常见（≥%.0f%%）而稿件没有：%s" % (100 * a.min_common, "、".join("%s %s" % (m, moves.get(m, "")) for m in common) or "无"))
            L.append("- 稿件有而对标少见（≤%.0f%%）：%s" % (100 * a.max_rare, "、".join("%s %s" % (m, moves.get(m, "")) for m in rare) or "无"))
            if first and dm:
                L.append("- 首句：稿件 %s；对标最常见 %s。末句：稿件 %s；对标最常见 %s。" % (
                    dm[0], first.most_common(1)[0][0], dm[-1], last.most_common(1)[0][0]))
    L.append("\n语步比例是对照，不是配方：缺一个常见语步，先问这一段是否需要承担那项功能；有一个少见语步，先问它是否属于别的节。")
    L.append("文本匹配不验证语步标签是否恰当、来源是否真实或是否为同类文献。需保存外部来源及独立语义复核；本脚本不能防止把真实短语故意标错类。")
    out = "\n".join(L) + "\n"
    if a.report:
        with M.wfile(a.report) as f:
            f.write(out)
    print(out[:4000] if not a.report else L[1].strip())
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
