#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
revision_diff.py — 两版稿件的段落级差异：哪里改了、改前改后原文、改动量。"声称已改"必须有这里的证据。

  python revision_diff.py 旧稿.md|docx 新稿.md|docx [--report changes.md] [--csv changes.csv] [--full]

输出每处改动的位置（节 / 小标题 / 段号）、类型（修改 / 新增 / 删除）、改前、改后、词数变化与相似度，以及各节汇总。
用途：修改记录（改前原文、改后原文、位置）；核对回复信里的 Changes；确认"已改"真的落盘；检查局部修改有没有波及别处。
它不能替代 Word 的修订模式：投稿要求修订稿时，仍需在 Word 中生成真实修订（用当前环境的 Word 文档工具）。
退出码：0 有改动；1 两版相同（不得声称已修改）；2 输入错误。
"""
import argparse, csv, difflib, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mslib as M

SEC_ZH = {"front": "题名页", "abstract": "摘要", "introduction": "引言", "methods": "方法", "results": "结果", "discussion": "讨论",
          "limitations": "局限", "conclusion": "结论", "references": "参考文献", "back": "文末声明/表图"}


def items(path):
    out, cnt = [], {}
    for b in M.parse(M.load_text(path)):
        if b["kind"] == "heading":
            out.append((b["sec"], b["sub"], "标题", b["text"])); continue
        cnt[b["sec"]] = cnt.get(b["sec"], 0) + 1
        out.append((b["sec"], b["sub"], "第%d段" % cnt[b["sec"]], b["text"]))
    return out


def loc(it):
    return "%s / %s / %s" % (SEC_ZH.get(it[0], it[0]), it[1] or "—", it[2])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("old"); ap.add_argument("new"); ap.add_argument("--report", default=""); ap.add_argument("--csv", default="")
    ap.add_argument("--full", action="store_true")
    a = ap.parse_args()
    for p in (a.old, a.new):
        if not os.path.exists(p):
            print("找不到 %s" % p, file=sys.stderr); return 2
    A, B = items(a.old), items(a.new)
    na, nb = [M.norm_for_match(x[3]) for x in A], [M.norm_for_match(x[3]) for x in B]
    rows = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, na, nb, autojunk=False).get_opcodes():
        if op == "equal":
            continue
        used = set()
        for i in range(i1, i2):
            best, bj = 0.0, None
            for j in range(j1, j2):
                if j in used:
                    continue
                r = difflib.SequenceMatcher(None, na[i], nb[j], autojunk=False).ratio()
                if r > best:
                    best, bj = r, j
            if bj is not None and best >= 0.45:
                used.add(bj); rows.append(("修改", A[i], B[bj], best))
            else:
                rows.append(("删除", A[i], None, 0.0))
        for j in range(j1, j2):
            if j not in used:
                rows.append(("新增", None, B[j], 0.0))
    wa = sum(M.count_words(x[3]) for x in A if x[0] != "references")
    wb = sum(M.count_words(x[3]) for x in B if x[0] != "references")
    summ = {}
    for t, o, n, r in rows:
        s = SEC_ZH.get((n or o)[0], (n or o)[0]); summ.setdefault(s, {"修改": 0, "新增": 0, "删除": 0})[t] += 1
    cut = (lambda s: s) if a.full else (lambda s: s if len(s) <= 400 else s[:400] + "…")
    L = ["# 修改差异：%s → %s\n" % (os.path.basename(a.old), os.path.basename(a.new)),
         "改动 %d 处；词数（不含参考文献）%d → %d（%+d）。\n" % (len(rows), wa, wb, wb - wa),
         "| 节 | 修改 | 新增 | 删除 |\n|---|---|---|---|"]
    L += ["| %s | %d | %d | %d |" % (s, v["修改"], v["新增"], v["删除"]) for s, v in summ.items()]
    L.append("\n| # | 类型 | 位置（新稿；删除为旧稿） | 改前 | 改后 | 词数变化 | 相似度 |\n|---|---|---|---|---|---|---|")
    for k, (t, o, n, r) in enumerate(rows, 1):
        before, after = (o[3] if o else ""), (n[3] if n else "")
        L.append("| %d | %s | %s | %s | %s | %+d | %s |" % (k, t, loc(n or o), cut(before).replace("|", "/"), cut(after).replace("|", "/"),
                                                         M.count_words(after) - M.count_words(before), ("%.2f" % r) if t == "修改" else "—"))
    out = "\n".join(L) + "\n"
    if a.report:
        with M.wfile(a.report) as f:
            f.write(out)
    if a.csv:
        with M.wfile(a.csv) as f:
            cw = csv.writer(f); cw.writerow(["no", "type", "location", "before", "after", "word_delta", "similarity"])
            for k, (t, o, n, r) in enumerate(rows, 1):
                cw.writerow([k, t, loc(n or o), o[3] if o else "", n[3] if n else "",
                             M.count_words(n[3] if n else "") - M.count_words(o[3] if o else ""), round(r, 3)])
    print(L[1].strip())
    return 0 if rows else 1


if __name__ == "__main__":
    sys.exit(main())
