# 作者说明

## 先看这里
- 能用的文件与用途：
- 状态：草稿完成 / 尚有待核项 / 投稿包备齐 / 已实际提交（只选有事实支持的一项）
- 本轮解决了什么：
- 还卡在哪里、作者下一步做什么：

## 执行条件
- 模式：EXECUTE / EXECUTE+NET / REASONING-ONLY
- 可用工具：scripts / websearch / browser / mcp:openalex / mcp:zotero / 其他
- 因为用户没有指定而采用的默认（作者可以改）：

## 待核事实（作者才知道，不能代填）
伦理批准号、利益冲突、资助、数据可得性、作者贡献、是否一稿多投、注册信息……

## 引文与对标（references/23）
- 承重引文的核对程度：见 citation_ledger.csv；这里只写汇总（例：12 条中 fulltext 5、abstract 4、metadata 3；doi_status 全部 resolved_crossref，工具与日期见台账）
- benchmark_mode：distribution / domain_pack / case / none；语料：；报告：
- 限制（无全文、篇数不足、只搜到元数据……）：

## 检查与裁决
- 跑了什么、退出码、没能运行的检查（不能算通过）：
- 判为误报而保留原文的项目、规则代码（如 section_lint R1）及理由：
