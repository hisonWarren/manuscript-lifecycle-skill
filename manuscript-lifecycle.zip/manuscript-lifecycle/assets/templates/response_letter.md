# Response to the editor and reviewers

**Manuscript ID:**
**Title:**

Dear Dr …,

Thank you for the opportunity to revise our manuscript. Our point-by-point responses follow. The main changes are:

- （实际主要修改一；按需带位置，不强凑数字或三条）
- （主要修改二）
- （主要修改三）

（结构变化：新增表、补充材料、文献。）（位置约定：页码和行号依据哪个文件；修订如何标示；意见如何编号。）

# Editor's comments

**Editor Comment 1**

> （原话）

**Response:** （直接回应问题；根据事实接受、部分接受、澄清或有据不接受，说明证据与实际修改；不默认审稿人总是正确）

**Changes:** （实际新增或修改摘录与定位；最终分页前用章节/段落锚点，页行标待更新，不编造）

# Reviewer 1

**Reviewer 1, Comment 1**

> （原话）

**Response:**

**Changes:**

# Additional changes made by the authors

- （修改中自己发现并改正的错误，逐条列出位置）

Yours sincerely,
