# Synthetic validation example

## Abstract
This synthetic example examines the association between perceived classroom support and examination scores. A cross-sectional survey of 240 students was analyzed using linear regression. Perceived support was positively associated with scores after adjustment for age and prior achievement. The observational design does not establish causality. These invented data are used only to test software integration.

## Introduction
Classroom support is a potential correlate of academic performance. Previous work motivates separating student perceptions from observed outcomes, but a numerical reference distribution cannot establish the quality of a particular study. The present synthetic example asks whether perceived support is associated with examination scores after accounting for prior achievement. It is a test input rather than a report of actual participants or findings.

## Methods
### Participants
The synthetic dataset contained 240 students, with one record per student. All records were complete. No actual individuals participated and no ethics approval is claimed. Scores and covariates were generated solely for a software validation exercise.
### Statistical analysis
Linear regression estimated the association between support and examination scores, adjusting for age and prior achievement. The model used all 240 simulated records. Estimates are illustrative and were specified in advance for the software probe; they should not be cited as research evidence. The same data were not used to construct the reference packages.

## Results
The adjusted standardized coefficient for support was 0.18, with a 95% confidence interval from 0.05 to 0.31. All 240 synthetic records contributed to this estimate. The example contains no subgroup comparisons or additional unreported analyses. The result represents a positive association within the generated data and is not evidence of an intervention effect.

## Discussion
The example illustrates a positive association in synthetic data. The adjusted estimate remains compatible with alternative explanations, including unmeasured confounding. It does not demonstrate a causal mechanism, and it does not support a recommendation to change classroom practice. Reference distributions can identify unusual information allocation, but each flag requires interpretation in the context of the manuscript and research design.

## Limitations
The records were generated for testing and have no empirical sampling frame. The cross-sectional structure cannot establish temporal order. Generalization to real schools, students, or other populations is therefore unwarranted.

## Conclusion
This synthetic example supports checking that domain packages can be read by the manuscript tools. It makes no substantive claim about education.
